package com.mabnets.moviemania.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PersonResponse {



    @SerializedName("results")
    private List<Person> results;
    @SerializedName("total_results")
    private String totalResults;

    @SerializedName("known_for")
    private List<Person> famous;

    public PersonResponse(List<Person> results, String totalResults,List<Person> famous) {
        this.results = results;
        this.totalResults = totalResults;
        this.famous=famous;
    }

    public List<Person> getFamous() {
        return famous;
    }

    public void setFamous(List<Person> famous) {
        this.famous = famous;
    }

    public List<Person> getResults() {
        return results;
    }

    public void setResults(List<Person> results) {
        this.results = results;
    }

    public String getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(String totalResults) {
        this.totalResults = totalResults;
    }
}
