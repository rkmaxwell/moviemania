package com.mabnets.moviemania.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mabnets.moviemania.R;
import com.mabnets.moviemania.model.Movie;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ErrorAdapter extends RecyclerView.Adapter<ErrorAdapter.ErrorViewHolder> {

    private Context mCtx;


    public ErrorAdapter(Context mCtx) {
        this.mCtx = mCtx;

    }

    @NonNull
    @Override
    public ErrorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.error_layout,null);
        return new ErrorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ErrorViewHolder holder, int position) {




    }

    @Override
    public int getItemCount() {
        return 1;
    }

    class ErrorViewHolder extends RecyclerView.ViewHolder{

        public ErrorViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
