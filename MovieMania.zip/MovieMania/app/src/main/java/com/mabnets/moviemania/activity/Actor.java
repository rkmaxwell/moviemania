package com.mabnets.moviemania.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.os.Bundle;
import android.widget.Toast;

import com.mabnets.moviemania.R;
import com.mabnets.moviemania.adapter.ErrorAdapter;
import com.mabnets.moviemania.adapter.PersonAdapter;
import com.mabnets.moviemania.model.Person;
import com.mabnets.moviemania.model.PersonResponse;
import com.mabnets.moviemania.rest.MovieApiService;

import java.util.ArrayList;
import java.util.List;

public class Actor extends AppCompatActivity {

    public static final String BASE_URL = "http://api.themoviedb.org/3/";
    private static Retrofit retrofit = null;
    private RecyclerView recyclerView = null;
    // insert your themoviedb.org API KEY here
    private final static String API_KEY = "5dcab5508faa63e6df647f02993a77f2";

    List<Person> personList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actor);


        personList=new ArrayList<>();
        recyclerView=(RecyclerView)findViewById(R.id.recycler_view_actor);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        getLatestActor();

    }

    private void getLatestActor(){

        if(retrofit == null){
            retrofit=new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }

        MovieApiService movieApiService=retrofit.create(MovieApiService.class);
        Call<PersonResponse> personResponseCall=movieApiService.getActorLatest(API_KEY);
        personResponseCall.enqueue(new Callback<PersonResponse>() {
            @Override
            public void onResponse(Call<PersonResponse> call, Response<PersonResponse> response) {


                List<Person> personLists=response.body().getResults();
                recyclerView.setAdapter(new PersonAdapter(personLists,R.layout.list_item_movie,getApplicationContext()));

            }

            @Override
            public void onFailure(Call<PersonResponse> call, Throwable t) {

                Toast.makeText(Actor.this, "Error, Please check your internet connection", Toast.LENGTH_SHORT).show();
                recyclerView.setAdapter(new ErrorAdapter(Actor.this));
            }
        });

    }
}
