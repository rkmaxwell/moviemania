package com.mabnets.moviemania.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mabnets.moviemania.R;
import com.mabnets.moviemania.model.Person;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.PersonViewHolder> {

    public static final String IMAGE_URL_BASE_PATH="http://image.tmdb.org/t/p/w342//";


    List<Person> personList;
    int rowLayout;
    Context context;

    public PersonAdapter(List<Person> personList, int rowLayout, Context context) {
        this.personList = personList;
        this.rowLayout = rowLayout;
        this.context = context;
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);
        return new PersonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonViewHolder holder, int position) {

        String image_url = IMAGE_URL_BASE_PATH + personList.get(position).getProfile();

        Glide.with(context)
                .load(image_url)
                .placeholder(R.drawable.africa)
                .error(R.drawable.ic_local_movies_black_24dp)
                .into(holder.movieImage);
        holder.movieTitle.setText(personList.get(position).getName());
        holder.movieDescription.setText(personList.get(position).getTitle());
        holder.rating.setText(String.format("%s",personList.get(position).getPopularity()));
    }

    @Override
    public int getItemCount() {
        return personList.size();
    }

    class PersonViewHolder extends RecyclerView.ViewHolder{

        LinearLayout moviesLayout;
        TextView movieTitle;
        TextView data;
        TextView movieDescription;
        TextView rating;
        ImageView movieImage;

        public PersonViewHolder(@NonNull View v) {
            super(v);
            moviesLayout = (LinearLayout) v.findViewById(R.id.movies_layout);
            movieImage = (ImageView) v.findViewById(R.id.movie_image);
            movieTitle = (TextView) v.findViewById(R.id.title);
            data = (TextView) v.findViewById(R.id.date);
            movieDescription = (TextView) v.findViewById(R.id.description);
            rating = (TextView) v.findViewById(R.id.rating);
        }
    }
}
