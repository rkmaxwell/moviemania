package com.mabnets.moviemania.activity;

public class Utils {

    public static final String video="http://192.168.43.182/restApp/video/video.mp4";
    public static String URLMessage="http://moviemania.mabnets.com/mania/contact.php";
}

