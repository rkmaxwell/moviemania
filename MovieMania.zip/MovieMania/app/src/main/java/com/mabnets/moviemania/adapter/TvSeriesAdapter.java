package com.mabnets.moviemania.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mabnets.moviemania.R;
import com.mabnets.moviemania.model.TvSerie;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TvSeriesAdapter extends RecyclerView.Adapter<TvSeriesAdapter.TvSeriesViewHolder> {

    public static final String IMAGE_URL_BASE_PATH="http://image.tmdb.org/t/p/w342//";

    List<TvSerie> tvSerieList;
    int rowLayout;
    Context context;

    public TvSeriesAdapter(List<TvSerie> tvSerieList, int rowLayout, Context context) {
        this.tvSerieList = tvSerieList;
        this.rowLayout = rowLayout;
        this.context = context;
    }

    @NonNull
    @Override
    public TvSeriesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);
        return new TvSeriesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TvSeriesViewHolder holder, int position) {

        String image_url = IMAGE_URL_BASE_PATH + tvSerieList.get(position).getPoster_path();

        Glide.with(context)
                .load(image_url)
                .placeholder(R.drawable.africa)
                .error(R.drawable.ic_local_movies_black_24dp)
                .into(holder.movieImage);
        holder.movieTitle.setText(tvSerieList.get(position).getName());
        holder.data.setText(tvSerieList.get(position).getFirst_air_date());
        holder.movieDescription.setText(tvSerieList.get(position).getOverview());
        holder.rating.setText(String.format("%s",tvSerieList.get(position).getVoteCount()));
    }

    @Override
    public int getItemCount() {
        return tvSerieList.size();
    }

    public static class TvSeriesViewHolder extends RecyclerView.ViewHolder{

        LinearLayout moviesLayout;
        TextView movieTitle;
        TextView data;
        TextView movieDescription;
        TextView rating;
        ImageView movieImage;
        public TvSeriesViewHolder(@NonNull View v) {
            super(v);

            moviesLayout = (LinearLayout) v.findViewById(R.id.movies_layout);
            movieImage = (ImageView) v.findViewById(R.id.movie_image);
            movieTitle = (TextView) v.findViewById(R.id.title);
            data = (TextView) v.findViewById(R.id.date);
            movieDescription = (TextView) v.findViewById(R.id.description);
            rating = (TextView) v.findViewById(R.id.rating);
        }
    }
}
