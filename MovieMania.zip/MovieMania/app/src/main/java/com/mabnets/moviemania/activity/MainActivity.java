package com.mabnets.moviemania.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import com.google.android.material.navigation.NavigationView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.mabnets.moviemania.R;
import com.mabnets.moviemania.adapter.ErrorAdapter;
import com.mabnets.moviemania.adapter.MoviesAdapter;
import com.mabnets.moviemania.model.Movie;
import com.mabnets.moviemania.model.MovieResponse;
import com.mabnets.moviemania.model.TvSerie;
import com.mabnets.moviemania.rest.MovieApiService;
import com.potyvideo.library.AndExoPlayerView;
import com.potyvideo.library.utils.PathUtil;
import com.potyvideo.library.utils.PublicFunctions;

import java.net.URISyntaxException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,MoviesAdapter.onItemClickListener {


    private static final String TAG = MainActivity.class.getSimpleName();
    public static final String BASE_URL = "http://api.themoviedb.org/3/";
    private static Retrofit retrofit = null;
    private RecyclerView recyclerView = null;
    // insert your themoviedb.org API KEY here
    private final static String API_KEY = "5dcab5508faa63e6df647f02993a77f2";

    AndExoPlayerView andExoPlayerView;


    int btnPosition=0;

    Button buttonAll,buttonPopular,buttonUpcoming,buttonTopRated;
    private int req_code = 129;
    List<Movie> movies;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        buttonAll=(Button)findViewById(R.id.btnAllMovie);
        buttonPopular=(Button)findViewById(R.id.btnPopular);
        buttonUpcoming=(Button)findViewById(R.id.btnUpcoming);
        buttonTopRated=(Button)findViewById(R.id.btnTopRated);

        buttonAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnPosition=1;
                buttonAll.setBackgroundResource(R.drawable.btn_pressed);
                connectAndGetApiData();
            }
        });
        buttonPopular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //btnPosition=2;
                buttonPopular.setBackgroundResource(R.drawable.btn_pressed);
                getPopular();
            }
        });
        buttonUpcoming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonUpcoming.setBackgroundResource(R.drawable.btn_pressed);
                getUpcoming();
            }
        });
        buttonTopRated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonTopRated.setBackgroundResource(R.drawable.btn_pressed);
                getTopRated();
            }
        });

        connectAndGetApiData();

        //max$code20
        //mabnetsc_epic
        //

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
       // getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {


        } else if (id == R.id.nav_slideshow) {

            startActivity(new Intent(MainActivity.this, TvSeries.class));
        } else if (id == R.id.nav_manage) {

            startActivity(new Intent(MainActivity.this,Actor.class));
        } else if (id == R.id.nav_share) {

            Intent shareIntent=new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.putExtra(Intent.EXTRA_TEXT,"Hey check out the app Movie Mania " +
                    "at https://mabnets.com/apps/");
            shareIntent.setType("text/plain");
            startActivity(shareIntent);

        } else if (id == R.id.nav_send) {

            startActivity(new Intent(MainActivity.this,Developer.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;




    }
    private void playVideo(){

        andExoPlayerView.setSource("https://www.youtube.com/watch?v=b_9NDcZTCRI");

    }

    private void selectLocaleVideo() {
        if (PublicFunctions.checkAccessStoragePermission(this)) {
            Intent intent = new Intent();
            intent.setType("video/*");
            intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Video"), req_code);
        }
    }
    private void loadMP4Locale(String filePath) {
        andExoPlayerView.setSource(filePath);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == req_code && resultCode == RESULT_OK) {
            Uri finalVideoUri = data.getData();
            String filePath = null;
            try {
                filePath = PathUtil.getPath(this, finalVideoUri);
                loadMP4Locale(filePath);
            } catch (URISyntaxException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void connectAndGetApiData(){
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }



        MovieApiService movieApiService1=retrofit.create(MovieApiService.class);
        Call<MovieResponse> movieResponseCall=movieApiService1.getLatest(API_KEY);
        movieResponseCall.enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                 movies=response.body().getResults();
                recyclerView.setAdapter(new MoviesAdapter(movies,R.layout.list_item_movie,getApplicationContext()));

            }

            @Override
            public void onFailure(Call<MovieResponse> call, Throwable t) {

                Toast.makeText(MainActivity.this, "Error, Please check your internet connection", Toast.LENGTH_SHORT).show();

                recyclerView.setAdapter(new ErrorAdapter(MainActivity.this));

            }
        });
    }

    @Override
    public void onItemClick(int position) {


    }

    public void getUpcoming(){


        MovieApiService movieApiService = retrofit.create(MovieApiService.class);
        Call<MovieResponse> call = movieApiService.getUpcoming(API_KEY);
        call.enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
               movies = response.body().getResults();
                recyclerView.setAdapter(new MoviesAdapter(movies, R.layout.list_item_movie, getApplicationContext()));
                Log.d(TAG, "all array"+response.body().getResults().toString());
            }
            @Override
            public void onFailure(Call<MovieResponse> call, Throwable throwable) {
                Log.e(TAG, throwable.toString());
            }
        });
    }
    public void getPopular(){


        MovieApiService movieApiService = retrofit.create(MovieApiService.class);
        Call<MovieResponse> call = movieApiService.getPopular(API_KEY);
        call.enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                List<Movie> movies = response.body().getResults();
                recyclerView.setAdapter(new MoviesAdapter(movies, R.layout.list_item_movie, getApplicationContext()));
                Log.d(TAG, "Number of movies received: " + movies.size());
            }
            @Override
            public void onFailure(Call<MovieResponse> call, Throwable throwable) {
                Log.e(TAG, throwable.toString());
            }
        });
    }
    public void getTopRated(){


        MovieApiService movieApiService = retrofit.create(MovieApiService.class);
        Call<MovieResponse> call = movieApiService.getTopRatedMovies(API_KEY);
        call.enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                List<Movie> movies = response.body().getResults();
                recyclerView.setAdapter(new MoviesAdapter(movies, R.layout.list_item_movie, getApplicationContext()));
                Log.d(TAG, "Number of movies received: " + movies.size());
            }
            @Override
            public void onFailure(Call<MovieResponse> call, Throwable throwable) {
                Log.e(TAG, throwable.toString());
            }
        });
    }
    protected void showContact(){


        String SHARE_URL="http://mabnets.com/apps/";
        Intent phoneIntent=new Intent(Intent.ACTION_SEND);
        phoneIntent.setData(Uri.parse(SHARE_URL));

        try{

            startActivity(phoneIntent);
            finish();

        }
        catch (Exception e){
            e.printStackTrace();

            Toast.makeText(MainActivity.this, "Sending failed, please try again later", Toast.LENGTH_LONG).show();
            //Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
