package com.mabnets.moviemania.rest;

import com.mabnets.moviemania.model.MovieResponse;
import com.mabnets.moviemania.model.PersonResponse;
import com.mabnets.moviemania.model.TvResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface MovieApiService {
    @GET("movie/top_rated")
    Call<MovieResponse> getTopRatedMovies(@Query("api_key") String apiKey);
    @GET("movie/now_playing")
    Call<MovieResponse> getLatest(@Query("api_key") String apiKey);
    @GET("movie/upcoming")
    Call<MovieResponse> getUpcoming(@Query("api_key") String apiKey);
    @GET("movie/popular")
    Call<MovieResponse> getPopular(@Query("api_key") String apiKey);
    @GET("movie/{movie_id}/videos")
    Call<MovieResponse> getVideo( @Query("api_key") String apiKey);

    @GET("tv/popular")
    Call<TvResponse> getTVPopular(@Query("api_key") String apiKey);
    @GET("tv/on_the_air")
    Call<TvResponse> getTVOnAir(@Query("api_key") String apiKey);
    @GET("tv/top_rated")
    Call<TvResponse> getTopRated(@Query("api_key") String apiKey);
    @GET("tv/latest")
    Call<TvResponse> getTvLatest(@Query("api_key") String apiKey);

    @GET("person/popular")
    Call<PersonResponse> getActorLatest(@Query("api_key") String apiKey);


}
