package com.mabnets.moviemania.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.mabnets.moviemania.R;
import com.mabnets.moviemania.adapter.ErrorAdapter;
import com.mabnets.moviemania.adapter.TvSeriesAdapter;
import com.mabnets.moviemania.model.TvResponse;
import com.mabnets.moviemania.model.TvSerie;
import com.mabnets.moviemania.rest.MovieApiService;

import java.util.List;

public class TvSeries extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    public static final String BASE_URL = "http://api.themoviedb.org/3/";
    public static Retrofit retrofit;
    private RecyclerView recyclerView = null;

    private Button buttonAll,buttonPopular,buttonTop,buttonUpcoming;
    // insert your themoviedb.org API KEY here
    private final static String API_KEY = "5dcab5508faa63e6df647f02993a77f2";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv_series);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_tv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        getTVSeriesData();

        buttonAll=(Button)findViewById(R.id.btnTVMovie);
        buttonPopular=(Button)findViewById(R.id.btnTVPopular);
        buttonUpcoming=(Button)findViewById(R.id.btnTvUpcoming);
        buttonTop=(Button)findViewById(R.id.btnTVTopRated);

        buttonAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getTVOnAir();
            }
        });
        buttonUpcoming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLatest();
            }
        }); buttonPopular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getTVSeriesData();
            }
        }); buttonTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getTopRated();
            }
        });
    }

    public void getTVSeriesData(){

        if(retrofit == null){

            retrofit=new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }

        MovieApiService movieApiService=retrofit.create(MovieApiService.class);
        Call<TvResponse> tvResponseCall=movieApiService.getTVPopular(API_KEY);
        tvResponseCall.enqueue(new Callback<TvResponse>() {
            @Override
            public void onResponse(Call<TvResponse> call, Response<TvResponse> response) {

                List<TvSerie> tvSeries=response.body().getResults();
                recyclerView.setAdapter(new TvSeriesAdapter(tvSeries,R.layout.list_item_movie,getApplicationContext()));

            }

            @Override
            public void onFailure(Call<TvResponse> call, Throwable t) {

                Toast.makeText(TvSeries.this, "Error, Check your internet connection", Toast.LENGTH_SHORT).show();
                recyclerView.setAdapter(new ErrorAdapter(TvSeries.this));
            }
        });


    }
    public void getTVOnAir(){

        MovieApiService movieApiService=retrofit.create(MovieApiService.class);
        Call<TvResponse> tvResponseCall=movieApiService.getTVOnAir(API_KEY);
        tvResponseCall.enqueue(new Callback<TvResponse>() {
            @Override
            public void onResponse(Call<TvResponse> call, Response<TvResponse> response) {

                List<TvSerie> tvSeries=response.body().getResults();
                recyclerView.setAdapter(new TvSeriesAdapter(tvSeries,R.layout.list_item_movie,getApplicationContext()));

            }

            @Override
            public void onFailure(Call<TvResponse> call, Throwable t) {

                Toast.makeText(TvSeries.this, "Error, check your internet connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void getTopRated(){

        MovieApiService movieApiService=retrofit.create(MovieApiService.class);
        Call<TvResponse> tvResponseCall=movieApiService.getTopRated(API_KEY);
        tvResponseCall.enqueue(new Callback<TvResponse>() {
            @Override
            public void onResponse(Call<TvResponse> call, Response<TvResponse> response) {

                List<TvSerie> tvSeries=response.body().getResults();
                recyclerView.setAdapter(new TvSeriesAdapter(tvSeries,R.layout.list_item_movie,getApplicationContext()));

            }

            @Override
            public void onFailure(Call<TvResponse> call, Throwable t) {

                Toast.makeText(TvSeries.this, "Error, check your internet connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void getLatest(){

        MovieApiService movieApiService=retrofit.create(MovieApiService.class);
        Call<TvResponse> tvResponseCall=movieApiService.getTopRated(API_KEY);
        tvResponseCall.enqueue(new Callback<TvResponse>() {
            @Override
            public void onResponse(Call<TvResponse> call, Response<TvResponse> response) {

                List<TvSerie> tvSeries=response.body().getResults();
                recyclerView.setAdapter(new TvSeriesAdapter(tvSeries,R.layout.list_item_movie,getApplicationContext()));

            }

            @Override
            public void onFailure(Call<TvResponse> call, Throwable t) {

                Toast.makeText(TvSeries.this, "Error, check your internet connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
