package com.mabnets.moviemania.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Person {


    @SerializedName("id")
    private Integer id;
    @SerializedName("name")
    private String name;
    @SerializedName("profile_path")
    private String profile;
    @SerializedName("popularity")
    private String popularity;
    @SerializedName("title")
    private String title;

    public Person(Integer id, String name, String profile, String popularity,String title) {
        this.id = id;
        this.name = name;
        this.profile = profile;
        this.popularity = popularity;
        this.title=title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }
}
